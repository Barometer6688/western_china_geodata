# 中国西部县域地理数据插件

这是一个 skills-only 私有插件。将原始 Excel 工作簿放入 `assets/workbooks/` 后，插件会按 `skills/county-geodata/SKILL.md` 的规则执行静态查询。

当前构建环境未挂载原始 Excel，因此本版本包含完整查询技能、数据定义与工作簿目录约定，但未包含二进制工作簿。
